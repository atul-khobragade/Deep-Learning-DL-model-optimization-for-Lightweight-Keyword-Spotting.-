ESC7 - Project code
Contributers - Karan Singh Kushwah & Atul Khobragade

Four Code files are provided - 
1. Embedded Project Model1 CNN
2. Embedded Project Model2 DNN
3.ELU Activation Function With Optimizer Experminet
4.ReLu Activation Function With Optimizer Experminet

How to run the code ?
1. Open Google colab on your browser
2. Sign in with your google account
3. Load the file you want to run
4. Select runtime(use default runtime)
5. Select run all cells


Features - 
1.Two DL model Implementation with high accuracy for Google Speech Command Dataset namely DNN and CNN.
2. Pre-processing of dataset in MFCC format.
3. Experiment with different layers and Parameters available(it really took long time )
4. Final model with best parameters and got the best accuracy and minimum loss with CNN and DNN.
5. Report is provided with full analysis of Project



Thank you :)
